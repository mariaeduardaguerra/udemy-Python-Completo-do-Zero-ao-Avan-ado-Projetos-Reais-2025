# nome = 'duda'
# print(nome)

# -------------- VARIÁVEIS PRIMITIVAS --------------

idade = 38 # (Int) números inteiros
peso = 80.4 # (Float) números decimais
nome = 'Duda' # (String) caracteres
ativo = True # (Bool) valores lógicos
resultado = None # (None) ausência de valor

print(type(idade))
print(type(nome))